package com.example.electric_bill_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectricBillSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
