package com.example.electric_bill_springboot.model;

public class Bill_structure {
    private int units;
    private int rate;


    public int getUnits() {
        return this.units;
    }

    public void setUnits(int units) {
        this.units = units;
    }

    public int getRate() {
        return this.rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }
    
}

