package com.example.electric_bill_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricBillSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricBillSpringbootApplication.class, args);
	}

}
