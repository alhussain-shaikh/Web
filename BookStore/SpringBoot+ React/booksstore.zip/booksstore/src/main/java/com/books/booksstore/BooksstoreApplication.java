package com.books.booksstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BooksstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksstoreApplication.class, args);
	}

}
