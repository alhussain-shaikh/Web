package com.books.booksstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.books.booksstore.model.Book;


public interface BooksRepository extends JpaRepository<Book, Long> {

}