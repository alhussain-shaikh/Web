import Footer from "./Footer";
import Header from "./Header";

const Home=()=>{
    return(
        <div>
            <Header/>
            <Footer/>
        </div>
    )
}
export default Home;