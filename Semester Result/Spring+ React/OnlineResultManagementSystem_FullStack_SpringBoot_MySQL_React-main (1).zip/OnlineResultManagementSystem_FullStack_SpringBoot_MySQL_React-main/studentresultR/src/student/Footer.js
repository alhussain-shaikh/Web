const Footer=()=>{
    return(
        <div>
            <ul>
                <li>Footer</li>
                <li>Footer</li>
                <li>Footer</li>
                <li>Footer</li>
            </ul>
        </div>
    )
}
export default Footer;