import React from 'react'

const AdminButton = () => {
  return (
    <div className='adminbu_con'>
        <div className='adminbu_con2'>
            <button style={{backgroundColor:"#2464a6",borderRadius:"7px"}}>AddStudent</button>
            <button style={{backgroundColor:"#bb3131",borderRadius:"7px"}}>Add Results</button>
            <button style={{backgroundColor:"#306b10",borderRadius:"7px"}}> Add ICA Marks</button>
        </div>
      

    </div>
  )
}

export default AdminButton
