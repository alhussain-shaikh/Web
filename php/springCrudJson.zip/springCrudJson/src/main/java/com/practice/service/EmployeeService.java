package com.practice.service;

import com.practice.model.Employee;
import com.practice.model.ResponseModel;

public interface EmployeeService {

	ResponseModel addEmployee(Employee employee);

}
