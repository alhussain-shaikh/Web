package com.practice.utils;

public class Constants {
	
	public static final String SUCCESS = "Success";
	public static final String FAIL = "Fail";
	public static final String EMPLOYEE_ADDED_SUCCESSFULLY = "Employee added Succesfully";
	public static final String EMPLOYEE_ALREADY_PRESENT = "Employee Id already present";
	public static final String EMPLOYEE_DETAILS_UPDATED_SUCCESSFULLY = "Employee details updated Succesfully";
	public static final String EMPLOYEE_DELETED_SUCCESSFULLY = "Employee deleted Succesfully";
	public static final String EMPLOYEE_NOT_FOUND = "Employee not Found";
}
